import React, { useState } from 'react';
import { Chat } from './components/Chat';
import { EvaluationChart } from './components/EvaluationChart';
import { Message, EvaluationMetrics } from './types';
import { BanIcon as BankIcon } from 'lucide-react';

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [showEvaluation, setShowEvaluation] = useState(false);
  const [metrics, setMetrics] = useState<EvaluationMetrics>({
    politeness: 0,
    clarity: 0,
    problemSolving: 0,
    productKnowledge: 0,
    customerFocus: 0,
  });

  const handleSendMessage = (text: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'staff',
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, newMessage]);

    // Simulate customer response
    setTimeout(() => {
      const customerResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getCustomerResponse(text),
        sender: 'customer',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, customerResponse]);
    }, 1000);
  };

  const getCustomerResponse = (staffMessage: string): string => {
    // Enhanced response logic for customer simulation
    const lowerMessage = staffMessage.toLowerCase();
    
    // Initial greeting patterns
    if (lowerMessage.includes('こんにちは') || lowerMessage.includes('いらっしゃいませ')) {
      return '口座を開設したいのですが。';
    }

    // Account opening related responses
    if (lowerMessage.includes('本人確認')) {
      return 'はい、運転免許証を持ってきました。';
    }
    
    if (lowerMessage.includes('運転免許証')) {
      return 'はい、どうぞ。普通預金口座を作りたいです。';
    }

    if (lowerMessage.includes('普通預金') || lowerMessage.includes('口座開設')) {
      return '給与の振込用に使いたいと思っています。';
    }

    if (lowerMessage.includes('給与')) {
      return 'はい、毎月25日に振り込まれる予定です。';
    }

    if (lowerMessage.includes('キャッシュカード')) {
      return '暗証番号は自分で決められますか？';
    }

    // Default responses for various situations
    if (lowerMessage.includes('お待ち')) {
      return 'はい、承知しました。';
    }

    if (lowerMessage.includes('ありがとう')) {
      return 'ありがとうございました。';
    }

    // Default response if no specific pattern is matched
    return '申し訳ありません、もう一度ご説明いただけますでしょうか？';
  };

  const handleEndChat = () => {
    // Evaluate based on the conversation
    const evaluation = evaluateConversation(messages);
    setMetrics(evaluation);
    setShowEvaluation(true);
  };

  const evaluateConversation = (messages: Message[]): EvaluationMetrics => {
    let metrics = {
      politeness: 4.0,
      clarity: 4.0,
      problemSolving: 4.0,
      productKnowledge: 4.0,
      customerFocus: 4.0
    };

    // Analyze staff messages for evaluation
    const staffMessages = messages.filter(m => m.sender === 'staff');
    
    staffMessages.forEach(message => {
      const text = message.text.toLowerCase();
      
      // Evaluate politeness
      if (text.includes('ございます') || text.includes('いたします')) {
        metrics.politeness += 0.2;
      }
      if (text.includes('申し訳')) {
        metrics.politeness += 0.1;
      }

      // Evaluate clarity
      if (text.includes('説明') || text.includes('ご案内')) {
        metrics.clarity += 0.1;
      }

      // Evaluate problem solving
      if (text.includes('ご提案') || text.includes('おすすめ')) {
        metrics.problemSolving += 0.2;
      }

      // Evaluate product knowledge
      if (text.includes('口座') || text.includes('預金')) {
        metrics.productKnowledge += 0.2;
      }

      // Evaluate customer focus
      if (text.includes('よろしい') || text.includes('いかがでしょう')) {
        metrics.customerFocus += 0.2;
      }
    });

    // Normalize scores to be between 0 and 5
    Object.keys(metrics).forEach(key => {
      metrics[key] = Math.min(5, Math.max(0, metrics[key]));
    });

    return metrics;
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-center mb-6">
          <BankIcon className="w-8 h-8 text-blue-600 mr-2" />
          <h1 className="text-2xl font-bold text-gray-800">
            銀行窓口応対トレーニング
          </h1>
        </div>

        {!showEvaluation ? (
          <Chat
            messages={messages}
            onSendMessage={handleSendMessage}
            onEndChat={handleEndChat}
          />
        ) : (
          <div className="space-y-6">
            <EvaluationChart metrics={metrics} />
            
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h2 className="text-xl font-semibold mb-4">対話履歴</h2>
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${
                      message.sender === 'staff' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    <div
                      className={`p-3 rounded-lg max-w-[70%] ${
                        message.sender === 'staff'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}
                    >
                      <p className="text-sm">{message.text}</p>
                      <p className="text-xs mt-1 opacity-70">
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-center">
              <button
                onClick={() => {
                  setShowEvaluation(false);
                  setMessages([]);
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                新しい対話を開始
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;