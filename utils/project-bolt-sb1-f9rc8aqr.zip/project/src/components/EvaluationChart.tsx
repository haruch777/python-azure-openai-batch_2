import React from 'react';
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from 'chart.js';
import { Radar } from 'react-chartjs-2';
import { EvaluationMetrics } from '../types';

ChartJS.register(
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend
);

interface EvaluationChartProps {
  metrics: EvaluationMetrics;
}

export const EvaluationChart: React.FC<EvaluationChartProps> = ({ metrics }) => {
  const data = {
    labels: [
      '丁寧さ',
      '説明の明確さ',
      '問題解決力',
      '商品知識',
      '顧客志向',
    ],
    datasets: [
      {
        label: '評価結果',
        data: [
          metrics.politeness,
          metrics.clarity,
          metrics.problemSolving,
          metrics.productKnowledge,
          metrics.customerFocus,
        ],
        backgroundColor: 'rgba(37, 99, 235, 0.2)',
        borderColor: 'rgba(37, 99, 235, 1)',
        borderWidth: 2,
      },
    ],
  };

  const options = {
    scales: {
      r: {
        angleLines: {
          display: true,
        },
        suggestedMin: 0,
        suggestedMax: 5,
      },
    },
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-xl font-semibold mb-4 text-center">対話評価結果</h2>
      <div className="w-full max-w-md mx-auto">
        <Radar data={data} options={options} />
      </div>
    </div>
  );
};