export interface Message {
  id: string;
  text: string;
  sender: 'staff' | 'customer';
  timestamp: Date;
}

export interface EvaluationMetrics {
  politeness: number;
  clarity: number;
  problemSolving: number;
  productKnowledge: number;
  customerFocus: number;
}